package homework;

/**
 * Name: Nathan Gouw
 * Date: May 10, 2024
 * Desc: Creating my own adaptation of a blackjack game
 */

//Import all of the essential items from outside of this class
import java.util.Scanner;
import java.util.Random;
import java.io.PrintWriter;
import java.io.File;

public class Blackjack {

	public static void main(String[] args) throws Exception {
		Scanner scan = new Scanner(System.in);
		File scoresFile = new File("highscores.txt");
		File saveFile = new File("prevSave.txt"); // create another file where they can call back their previous save if
													// they had on

		// Welcome message and initialization of variables
		System.out.println("Welcome to Blackjack!!!");
		String rules;
		String splitAns = "";
		String name = "";
		String prevName = "";
		int tokens = 2000;
		int prev = 0;
		boolean playerBlackJack = false;
		boolean[] playerAces = new boolean[4];
		boolean[] dealerAces = new boolean[4];
		boolean play = true;
		int numPlayerAces = 0;
		int numDealerAces = 0;

		// display the rules of the game
		do {
			System.out.println("Would you like to know the rules to the game? (y/n)");
			rules = scan.next().toLowerCase();
			if (rules.equals("y") || rules.equals("yes")) { // if they answered 'y' or 'yes' then
				// display the rules
				System.out.println(
						"1. Blackjack is played with one standard 52-card deck, which is shuffled at the beginning of each hand. ");
				System.out.println();
				System.out.println(
						"2. After receiving their initial two cards, players have the option to \"hit\" or \"stand\". ");
				System.out.println(
						"   If a player chooses to hit, they receive an additional card to try to improve their hand total. ");
				System.out.println(
						"   They can continue to hit as many times as they like until they are satisfied with their hand or they ");
				System.out
						.println("   exceed 21 points, which is called \"busting\" and results in an automatic loss. ");
				System.out.println(
						"   If a player chooses to stand, they decline any further cards and stick with their current hand total. ");
				System.out.println(
						"   Players typically choose to stand when they are confident that their current hand is strong enough to ");
				System.out
						.println("   beat the dealer, or when they are close to 21 and don't want to risk going over.");
				System.out.println();
				System.out
						.println("3. Players can split their hand once if their first two cards have the same value. ");
				System.out.println("   The bet amount for the split hand must be the same as the original bet.");
				System.out.println();
				System.out.println(
						"4. Numbered cards are valued at their face value, while Jacks, Queens, and Kings are each worth 10 points. ");
				System.out.println(
						"   Aces can be counted as either 1 or 11 points, depending on which value benefits the player.");
				System.out.println();
				System.out.println(
						"5. Achieving a blackjack (a total of 21 on the initial hand) pays out at a rate of 3 to 2 of the bet value. ");
				System.out.println("   (Ex: If bet 10 and they get a blackjack, they will get 15)");
				System.out.println();
				System.out.println(
						"6. The dealer will continue to take cards until they reach a total of at least 17 points or bust. ");
				System.out.println(
						"   If the dealer and player both have blackjack or they both stand with the same point value, it results in a push (tie).");

			} else if (rules.equals("n") || rules.equals("no")) { // if they say no

				// tell them we are starting the game
				System.out.println("Alright then lets start the game!");
			} else { // otherwise

				// tell them to redo it
				System.out.println("Invalid input");
				System.out.println("Please try again");

			}
			// do this all while rules is not equal to n, no, y or yes
		} while (!rules.equals("n") && !rules.equals("no") && !rules.equals("y") && !rules.equals("yes"));

		// initialization of variables for saved game
		String cont = "";
		boolean save = false;

		if (saveFile.exists()) { // if the file exists]
			// use a try-catch
			try {
				Scanner saveScan = new Scanner(saveFile); // create a new scanner for the save file
				if (saveScan.hasNextInt()) { // if there is another integer in the save file
					prev = saveScan.nextInt(); // find the previous score and previous name
					prevName = saveScan.nextLine().trim(); // trim is for deleting all spaces at the end or beginning of
															// the string
					save = true; // set save to true
				} else { // otherwise
					save = false; // set save to false
				}
				// catch if there is an exception and name it e
			} catch (Exception e) {
				save = false;
			}
			;
		} else {
			// ask for name if no saved slots are found
			System.out.println("What is your name? This will be saved for high scores");
			scan.nextLine();
			name = scan.nextLine().trim();
			System.out.println();
		}
		System.out.println(); // add an extra line

		// if they have a saved game
		if (save == true) {

			System.out.println("It looks like you have a saved slot!!");
			cont = "y";
			do { // make a do loop so that it will repeat if they don't answer correctly

				// if cont is not equal to n, no, y, or yes
				if (!cont.equals("n") && !cont.equals("no") && !cont.equals("y") && !cont.equals("yes")) {
					// tell them it is an invalid input
					System.out.println("Invalid input... Please enter y or n");
				}
				Scanner scanFromSave = new Scanner(saveFile); // create a scanner for the save file
				// ask if they want to continue from the previous game
				System.out.println("Would you like to continue from that game? (y/n)");
				cont = scan.next().toLowerCase();
				prev = scanFromSave.nextInt(); // find the score and name of the previous game
				prevName = scanFromSave.nextLine().trim();
				scanFromSave.close(); // close the scanner
			//do this while cont is not equal to n, no, y, or yes
			} while (!cont.equals("n") && !cont.equals("no") && !cont.equals("y") && !cont.equals("yes"));

		} else { //otherwise
			// if they don't have a saved slot
			System.out.println("Looks like you don't have any saved slots!");

		}

		if (cont.equals("y") || cont.equals("yes")) { //if cont was equal to yes or y
			// set it to the previous amount of tokens and name
			tokens = prev; 
			name = prevName;
			//welcome them and tell them their starting tokens
			System.out.println("Welcome back " + name + "!!!"); 
			System.out.println("You are starting off with " + tokens + " tokens!");
		} else if(name.equals("")){ //otherwise
			// start a new game
			System.out.println("What is your name? This will be saved for high scores");
			scan.nextLine();
			name = scan.nextLine().trim();
			System.out.println();
		}

		// initialize more variables
		boolean again = true;
		boolean[] dealtCards = new boolean[52]; // create an array that stores 52 boolean values
		int playerTotal = 0; // to indicate how many points they have at the moment
		int dealerTotal = 0; // to indicate how many points they have at the moment
		String start; // initialize start
		int userBet = -1;
		String opt = ""; // initialize opt
		String saveForNext = "";

		// game continuation loop
		do {// make a loop until they don't want to play again
			do {
				if (tokens <= 0) {
					System.out.println("Game Over! You have run out of tokens.");
					play = false; // End the game

					try {
						// Erase contents of the save file
						PrintWriter saveWriter = new PrintWriter(saveFile);
						saveWriter.write(""); // Write an empty string to the file
						saveWriter.close();
					} catch (Exception e) {
						System.out.println("Error clearing save file: " + e.getMessage());
					}
					break; // Exit the loop
				}

				//tell them their tokens and ask them what they want to do
				System.out.println("You currently have " + tokens + " tokens");
				System.out.println("Do you want to play, cash out, or look at the scoreboard? (p/c/s)");
				start = scan.next().toLowerCase();
				if (start.equals("p") || start.equals("play")) {
					//will automatically start the game
				} else if (start.equals("c") || start.equals("cash")) {
					PrintWriter writeSave = new PrintWriter(saveFile);
					//make a do loop so that it can be assured they are entering the correct things
					do {
						System.out.println("Would you like to save your tokens for the next time? (y/n)");
						System.out.println("[Note] If you say no, it will be added to the scoreboard");
						saveForNext = scan.next().toLowerCase();
						if (saveForNext.equals("y") || saveForNext.equals("yes")) { //if they said yes
							//save their tokens and name
							System.out.println("Saving...");
							writeSave.println(tokens + " " + name);
							System.out.println(tokens + " tokens have been saved for " + name);
							writeSave.close(); //close the printWriter
						} else if (saveForNext.equals("n") || saveForNext.equals("no")) { //else if they said no
							int[] scoresArray = null; //reset the scoresArray and namesArray
							String[] namesArray = null;
							try { //try-catch so that if a string value shows, it won't end the program
								//create a scanner system
								Scanner scoresScan = new Scanner(scoresFile);
								
								//set the number of scores to 0
								int numScores = 0;
								while (scoresScan.hasNextInt()) { //while there is another integer in the file
									scoresScan.nextInt(); //go to the next int and next line
									scoresScan.nextLine();
									numScores++; //add one to scores to count number of scores
								}

								// create arrays to store the scores and names
								scoresArray = new int[numScores + 1];
								namesArray = new String[numScores + 1];

								// add the new score and name
								scoresArray[numScores] = tokens;
								namesArray[numScores] = name;

								// reset the scanner to go back to the beginning
								scoresScan.close();
								scoresScan = new Scanner(scoresFile);

								// read the existing scores and names from the file and store them into the
								// array
								for (int i = 0; i < numScores; i++) {
									scoresArray[i] = scoresScan.nextInt();
									namesArray[i] = scoresScan.nextLine().trim();
								}

								// close the scanner
								scoresScan.close();
								
								//use bubble sort to sort in descending order
								for (int i = 0; i < scoresArray.length - 1; i++) {
									for (int j = 0; j < scoresArray.length - i - 1; j++) {
										if (scoresArray[j] < scoresArray[j + 1]) {
											// Swap scores
											int tempScore = scoresArray[j];
											scoresArray[j] = scoresArray[j + 1];
											scoresArray[j + 1] = tempScore;

											// Swap names
											String tempName = namesArray[j];
											namesArray[j] = namesArray[j + 1];
											namesArray[j + 1] = tempName;
										}
									}
								}

								// Write back only the top 10 scores and names to the file
								PrintWriter scoresWriter = new PrintWriter(scoresFile);
								for (int i = 0; i < Math.min(10, scoresArray.length); i++) {
									scoresWriter.println(scoresArray[i] + " " + namesArray[i]);
								}
								scoresWriter.close(); //close the printWriter to save

							} catch (Exception e) { //catch anything if there is an error and call it 'e'
								System.out.println("Error writing the new score"); 
							}
						}
					//do this while saveForNext is equal to n, no, y, or yes
					} while (!saveForNext.equals("n") && !saveForNext.equals("no") && !saveForNext.equals("y")
							&& !saveForNext.equals("yes"));
					again = false;
					break; //end the loop 
				} else if (start.equals("s") || start.equals("score")) {
					if (scoresFile.exists()) { // Check if the file exists
						try { //try-catch to make sure that it doesnt stop if the file isnt there
							Scanner scoresScan = new Scanner(scoresFile);

							// Determine the number of scores in the file
							int numScores = 0;
							while (scoresScan.hasNextInt()) {
								scoresScan.nextInt();
								scoresScan.nextLine();
								numScores++;
							}

							// Create an array to store the scores
							int[] scoresArray = new int[numScores];
							String[] namesArray = new String[numScores];

							// Reset the scanner to read from the beginning of the file
							scoresScan.close();
							scoresScan = new Scanner(scoresFile);

							// Read the scores from the file and store them in the array
							for (int i = 0; i < numScores; i++) {
								scoresArray[i] = scoresScan.nextInt();
								// read the entire line as the name
								namesArray[i] = scoresScan.nextLine().trim();
							}

							// Output the scores
							System.out.println("Your scores:");
							for (int i = 0; i < numScores; i++) {
								System.out.println((i + 1) + ". " + scoresArray[i] + ", " + namesArray[i]);
							}

							// Close the scanner
							scoresScan.close();

						} catch (Exception e) { //catch if there is an error
							System.out.println("Error reading scores");
						}
					} else { //other wise
						//tell them they have no previous scores
						System.out.println("You have no previous scores");
					}

					System.out.println();
					// Ask the user what they want to do next
					System.out.println("Do you want to play? (y/n)");
					start = scan.next().toLowerCase();

					// Handle the user's choice
					if (start.equals("y") || start.equals("yes")) {
						// Continue with the game
					} else if (start.equals("n") || start.equals("no")) {
						play = false;
						break; //end the loop
					} else { //otherwise
						//tell them that they have to answer with the following
						System.out.println("Invalid input, please answer with p, c, or s");
					}
					if (play == false) { //if play is equal to false
						break; //end the loop
					}
				} else { //otherwise
					//tell them they need to answer with the following
					System.out.println("Invalid input, please answer with p, c, or s");
				}
				
			//do this all while start is equal to c, cash, p, play, s, or score
			} while (!start.equals("c") && !start.equals("cash") && !start.equals("p") && !start.equals("play")
					&& !start.equals("s") && !start.equals("score"));
			//if again is false or play is equal to false
			if (again == false || play == false) {
				//end the loop and tell them thanks for playing
				System.out.println("Thanks for playing!");
				break;
			}
			System.out.println(); // add another line
			System.out.println("You have " + tokens + " tokens"); // output the amount of tokens they have
			do { //do this while the userbet is a factor of 5, it is greater than 0, and the user's tokens is equal to or higher
				try { //try-catch to make sure user isnt inputting string values
					//find out how much they want to bet and store it in userbet
					System.out.println("How much do you want to bet?? (In intervals of 5)");
					userBet = scan.nextInt();
					if (userBet % 5 == 0 && userBet > 0 && userBet <= tokens) {
						System.out.println();
						System.out.println("You are betting " + userBet + " tokens");
					} else {
						System.out.println("Invalid input, please input in intervals of 5");
						System.out.println(); // create another line
					}
				} catch (Exception e) {
					System.out.println("Please only input integer values");
					scan.next();
				}

			} while (!(userBet % 5 == 0 && userBet > 0 && userBet <= tokens));
			
			//find both cards with the method cardGen
			int[] pCard1 = cardGen(dealtCards, playerAces);
			//if the card is a jack, queen, or king, add only 10 to the player total
			if (pCard1[0] == 11 || pCard1[0] == 12 || pCard1[0] == 13) {
				playerTotal += 10;
				//otherwise, if it is equal to 1
			} else if (pCard1[0] == 1) {
				if (playerTotal + 11 <= 21) { //and if you add 11 and it is under 21
					playerTotal += 11; //add 11
				} else { //otherwise
					playerTotal += 1; //set it to one (there are more stuff in methods for this logic)
				}
			} else { //otherwise
				playerTotal += pCard1[0]; //add the values to the total
			}
			
			int[] pCard2 = cardGen(dealtCards, playerAces);
			if (pCard2[0] == 11 || pCard2[0] == 12 || pCard2[0] == 13) {
				playerTotal += 10;
			} else if (pCard2[0] == 1) {
				if (playerTotal + 11 <= 21) {
					playerTotal += 11;
				} else {
					playerTotal += 1;
				}
			} else {
				playerTotal += pCard2[0];
			}
			
			//if the playertotal is equal to 21, set the boolean to true
			if (playerTotal == 21) {
				playerBlackJack = true;
			}
			
			//create 2 new playerCards, and find the output through method translate
			String[] playerCards = new String[2];
			playerCards[0] = translate(pCard1);
			playerCards[1] = translate(pCard2);
			
			//output the user's cards and totals
			System.out.println("Your cards: ");

			printCardsSideBySide(playerCards);

			System.out.println("Your total: " + playerTotal);
			System.out.println();
			
			//output the dealer's cards and total
			System.out.println("Dealer's cards: ");
			
			//find the dealer's cards and use the same logic as above for the following
			int[] dCard1 = cardGen(dealtCards, dealerAces);
			if (dCard1[0] == 11 || dCard1[0] == 12 || dCard1[0] == 13) {
				dealerTotal += 10;
			} else if (dCard1[0] == 1) {
				if (dealerTotal + 11 <= 21) {
					dealerTotal += 11;
				} else {
					dealerTotal += 1;
				}
			} else {
				dealerTotal += dCard1[0];
			}
			
			//find the dealer's second card but don't flip it up yet
			int[] dCard2 = cardGen(dealtCards, dealerAces);
			String[] dealerCards = new String[2]; //create an array full with dealers cards
			//add the card's output to the array through method translate
			dealerCards[0] = translate(dCard1); 
			dealerCards[1] = "  ";
			
			//output the dealer's cards
			printCardsSideBySide(dealerCards);

			System.out.println("Dealer's total: " + dealerTotal);
			System.out.println(); // add another line

			do { //repeat this while they want to keep playing
				if (playerBlackJack == true) { //if the boolean is equal to true
					//multiply their bet by 3/2 and add it to their total
					System.out.println("You got a Blackjack!!"); 
					int blackJackPay = (int) (userBet * 1.5); // pay 3:2
					blackJackPay = (blackJackPay + 2) / 5 * 5;
					System.out.println("You won " + blackJackPay + " tokens!!");
					tokens += blackJackPay;
					reset(dealtCards, playerTotal, dealerTotal, playerAces, dealerAces, playerBlackJack, numPlayerAces,
							numDealerAces, splitAns);
					playerBlackJack = false;
					break;
					
					//otherwise if both the cards numbers are the same, they can split, so ask them if they want to
				} else if (playerCards[0].substring(0, playerCards[0].length() - 1).equals(
						playerCards[1].substring(0, playerCards[1].length() - 1)) && (tokens - (2 * userBet)) >= 0) {
					do {//make sure they are inputting correct thing
						//ask them if they want to split
						System.out.println("You have the option to split!!");
						System.out.println("Do you want to split? (y/n)");
						splitAns = scan.next().toLowerCase();

					} while (!splitAns.equals("n") && !splitAns.equals("no") && !splitAns.equals("y")
							&& !splitAns.equals("yes"));
				}
				
				//if splitAns is equal to y or yes
				if (splitAns.equals("y") || splitAns.equals("yes")) {
					// Handle the split
					tokens = handleSplit(playerCards, playerTotal, userBet, tokens, dealtCards, playerAces, scan,
							dealerCards, dealerTotal, dCard2, dealerAces);
					reset(dealtCards, playerTotal, dealerTotal, playerAces, dealerAces, playerBlackJack, numPlayerAces,
							numDealerAces, splitAns);
					splitAns = "";
					break; //end the loop
				} else if (splitAns.equals("n") || splitAns.equals("no")) {
					System.out.println("Very well then..");
				}
				try { //try catch to make sure they are inputting correct thing
					System.out.println("Do you want to hit or stand? (h/s)");
					opt = scan.next().toLowerCase();
					if (opt.equals("h") || opt.equals("hit")) {

						// Create a new array to hold the player's cards including the new one
						String[] tempPlayerCards = new String[playerCards.length + 1];

						// Copy the existing player cards to the new array
						for (int i = 0; i < playerCards.length; i++) {
							tempPlayerCards[i] = playerCards[i];
						}

						// Generate a new card and translate it to a string representation
						int[] newCard = cardGen(dealtCards, playerAces);
						String newCardString = translate(newCard);

						// Add the new card to the end of the new array
						tempPlayerCards[tempPlayerCards.length - 1] = newCardString;

						// Update the player's cards with the new array
						playerCards = tempPlayerCards;

						// Recalculate the player's total
						playerTotal = calculateTotal(playerCards, 0, playerAces);
						
						//output player's cards
						System.out.println("Your cards: ");
						printCardsSideBySide(playerCards);

						System.out.println("Your total: " + playerTotal);
						System.out.println();
						
						//output dealer's cards
						System.out.println("Dealer's cards: ");

						printCardsSideBySide(dealerCards);

						dealerTotal = 0;
						
						//calculate the dealer's total
						dealerTotal = calculateTotal(dealerCards, dealerTotal, dealerAces);

						//output the dealer's total
						System.out.println("Dealer's total: " + dealerTotal);
						System.out.println(); // add another line
						again = true;
						
						//if the player's total goes over 21, its a bust and they lose
						if (playerTotal > 21) {
							System.out.println("You busted!! You lost " + userBet + " tokens");
							tokens -= userBet;
							reset(dealtCards, playerTotal, dealerTotal, playerAces, dealerAces, playerBlackJack,
									numPlayerAces, numDealerAces, splitAns);

							//otherwise if the playertotal is equal to 21, then they win
						} else if (playerTotal == 21) {
							System.out.println("You won!! You gained " + userBet + " tokens");
							tokens += userBet;
							reset(dealtCards, playerTotal, dealerTotal, playerAces, dealerAces, playerBlackJack,
									numPlayerAces, numDealerAces, splitAns);
						}
						//otherwise if the player chose to stand
					} else if (opt.equals("s") || opt.equals("stand")) {
						System.out.println("You chose to stand");

						// Reveal the dealer's second card
						dealerCards[1] = translate(dCard2);
						dealerTotal = calculateTotal(dealerCards, 0, dealerAces);

						//output the user's cards
						System.out.println("Your cards: ");
						printCardsSideBySide(playerCards);

						System.out.println("Your total: " + playerTotal);

						//output the dealer's cards
						System.out.println("Dealer's cards: ");
						printCardsSideBySide(dealerCards);

						System.out.println("Dealer's total: " + dealerTotal);

						// Dealer's turn to draw cards until reaching at least 17
						while (dealerTotal < 17) {
							// Generate a new card and update dealtCards and dealerAces
							int[] newDealCard = cardGen(dealtCards, dealerAces);

							// Create a new array with an additional slot for the new card
							String[] tempDealerCards = new String[dealerCards.length + 1];

							// Copy existing dealer cards to the new array
							for (int i = 0; i < dealerCards.length; i++) {
								tempDealerCards[i] = dealerCards[i];
							}

							// Translate the new card and add it to the new array
							tempDealerCards[tempDealerCards.length - 1] = translate(newDealCard);

							// Update dealerCards with the new array
							dealerCards = tempDealerCards;

							// Recalculate the dealer's total
							dealerTotal = calculateTotal(dealerCards, 0, dealerAces);
							
							//output the user's cards
							System.out.println("Your cards: ");
							printCardsSideBySide(playerCards);

							System.out.println("Your total: " + playerTotal);

							//output the dealer's cards
							System.out.println("Dealer's cards: ");
							printCardsSideBySide(dealerCards);

							System.out.println("Dealer's total: " + dealerTotal);
						}

						// Determine the outcome of the game
						if (dealerTotal > 21) {
							System.out.println("Dealer busted! You won " + userBet + " tokens!");
							tokens += userBet;
						} else if (dealerTotal > playerTotal) {
							System.out.println("Dealer wins! You lose " + userBet + " tokens");
							tokens -= userBet;
						} else if (dealerTotal == playerTotal) {
							System.out.println("It's a push! Nothing happens to your tokens!");
						} else {
							System.out.println("You won " + userBet + " tokens!");
							tokens += userBet;
						}

						reset(dealtCards, playerTotal, dealerTotal, playerAces, dealerAces, playerBlackJack,
								numPlayerAces, numDealerAces, splitAns);
						break; //end the loop
					} else {
						System.out.println("Invalid input");
					}
				} catch (Exception e) {
					System.out.println("Please enter an integer value");
				}

			} while (!(opt.equals("s") || opt.equals("stand")) && playerTotal < 21);
			//reset everything
			for (int i = 0; i < playerCards.length; i++) {
				playerCards[i] = null;
			}

			for (int i = 0; i < dealerCards.length; i++) {
				dealerCards[i] = null;
			}

			playerTotal = 0;
			dealerTotal = 0;

		} while (again == true);

	}

	//create method reset where it resets all values so the game can start again
	public static void reset(boolean[] dealtCards, int playerTotal, int dealerTotal, boolean[] pHasAce,
			boolean[] dHasAce, boolean playerBlackJack, int numPlayerAces, int numDealerAces, String splitAns) {
		for (int i = 0; i < dealtCards.length; i++) {
			dealtCards[i] = false;
		}
		for (int i = 0; i < pHasAce.length; i++) {
			pHasAce[i] = false;
		}
		for (int i = 0; i < dHasAce.length; i++) {
			dHasAce[i] = false;
		}
		splitAns = "";
		playerTotal = 0;
		dealerTotal = 0;
		playerBlackJack = false;
		numPlayerAces = 0; // Reset the number of player aces
		numDealerAces = 0; // Reset the number of dealer aces
	}

	
	//create method calculate total so that the total will be calculated
	public static int calculateTotal(String[] cards, int currentTotal, boolean[] aces) {
		int total = currentTotal;
		int numAces = 0; // Counter to track the number of aces

		// calculate the total and count aces
		for (int i = 0; i < cards.length; i++) {
			String card = cards[i];
			String cardValue = card.substring(0, card.length() - 1).trim(); // Trim any leading/trailing spaces
			int value;
			if (cardValue.isEmpty()) {
				value = 0;
			} else if (cardValue.equals("J") || cardValue.equals("Q") || cardValue.equals("K")) {
				value = 10;
			} else if (cardValue.equals("A")) {
				value = 11;
				numAces++; // Increment the ace counter
			} else {
				value = Integer.valueOf(cardValue); // For number cards, convert the string to integer
			}
			total += value;
		}

		// adjust for aces if total is over 21
		while (total > 21 && numAces > 0) {
			total -= 10; // Convert an ace from 11 to 1
			numAces--; // Decrement the remaining ace counter
		}

		return total; //return the total
	}

	
	//create a method to make numbered values into the output for the user to see
	public static String translate(int[] cards) {
		String cardName = "";
		
		//find the correct numbers
		if (cards[0] == 11) {
			cardName += "J";
		} else if (cards[0] == 12) {
			cardName += "Q";
		} else if (cards[0] == 13) {
			cardName += "K";
		} else if (cards[0] == 1) {
			cardName += "A";
		} else if (cards[0] <= 10 && cards[0] >= 2) {
			cardName += cards[0];
		}

		
		//find the correct suits
		if (cards[1] == 1) {
			cardName += "♠";
		} else if (cards[1] == 2) {
			cardName += "♥";
		} else if (cards[1] == 3) {
			cardName += "♦";
		} else if (cards[1] == 4) {
			cardName += "♣";
		}

		return cardName; //return the cardName
	}

	//create method cardGen to generate a card
	public static int[] cardGen(boolean[] dealtCards, boolean[] aces) {
		//initialize the variables
		Random rand = new Random();
		int cardIndex;

		// Find an index for a card that hasn't been dealt
		do {
			cardIndex = rand.nextInt(52); // generates a number between 0 and 51
		} while (dealtCards[cardIndex]);

		// Mark the card as dealt
		dealtCards[cardIndex] = true;

		// Calculate the card number and suit
		int number = (cardIndex % 13) + 1;
		int suit = (cardIndex / 13) + 1;

		// Check if the card is an Ace and update aces array
		if (number == 1) {
			for (int i = 0; i < aces.length; i++) {
				if (!aces[i]) {
					aces[i] = true;
					break;
				}
			}
		}

		return new int[] { number, suit }; //return the number and the suit
	}

	//create method printCardsSideBySide to literally print them side by side
	public static void printCardsSideBySide(String[] cards) {
		//create strings for each of the lines
		String[] topLines = new String[cards.length];
		String[] secondLines = new String[cards.length];
		String[] middleLines1 = new String[cards.length];
		String[] middleLines2 = new String[cards.length];
		String[] fourthLines = new String[cards.length];
		String[] bottomLines = new String[cards.length];

		//create a for loop to put the translated cards into the card and output it
		for (int i = 0; i < cards.length; i++) {
			String rank = cards[i].substring(0, cards[i].length() - 1);
			String suit = cards[i].substring(cards[i].length() - 1);
			topLines[i] = " _______ ";
			secondLines[i] = "|" + rank + suit + repeatSpace(7 - (rank.length() + suit.length())) + "|";
			middleLines1[i] = "|       |";
			middleLines2[i] = "|       |";
			fourthLines[i] = "|" + repeatSpace(7 - (rank.length() + suit.length())) + rank + suit + "|";
			bottomLines[i] = " ‾‾‾‾‾‾‾ ";
		}

		// Print each part of the card side by side
		printLines(topLines);
		printLines(secondLines);
		printLines(middleLines1);
		printLines(middleLines2);
		printLines(fourthLines);
		printLines(bottomLines);
	}

	//declare method handleSplit to handle when the user gets a split
	public static int handleSplit(String[] playerCards, int playerTotal, int userBet, int tokens, boolean[] dealtCards,
			boolean[] playerAces, Scanner scan, String[] dealerCards, int dealerTotal, int[] dCard2,
			boolean[] dealerAces) {
		
		//create a method for each of the hands
		String[] hand1 = new String[2];
		String[] hand2 = new String[2];
		
		//set the hands to the number that was used for the split
		hand1[0] = playerCards[0];
		hand2[0] = playerCards[1];

		
		//find new cards for the second card for each hand
		int[] newCard1 = cardGen(dealtCards, playerAces);
		hand1[1] = translate(newCard1);
		int hand1Total = calculateTotal(hand1, 0, playerAces);

		int[] newCard2 = cardGen(dealtCards, playerAces);
		hand2[1] = translate(newCard2);
		int hand2Total = calculateTotal(hand2, 0, playerAces);

		//play both hands
		System.out.println("Playing first hand...");
		tokens = playHand(hand1, hand1Total, userBet, tokens, dealtCards, playerAces, scan, dealerCards, dealerTotal,
				dCard2, dealerAces);

		System.out.println(); // add another line
		System.out.println("Your total now is " + tokens);

		System.out.println("Playing second hand...");
		tokens = playHand(hand2, hand2Total, userBet, tokens, dealtCards, playerAces, scan, dealerCards, dealerTotal,
				dCard2, dealerAces);
		return tokens; //return tokens 
	}

	//create method playHand to play the hand
	public static int playHand(String[] playerCards, int playerTotal, int userBet, int tokens, boolean[] dealtCards,
			boolean[] playerAces, Scanner scan, String[] dealerCards, int dealerTotal, int[] dCard2,
			boolean[] dealerAces) {
		
		boolean continuePlaying = true;
		String opt = "";
		
		
		do {//do while continuePlaying is true
			
			//output user's cards
			System.out.println("Your cards: ");
			
			printCardsSideBySide(playerCards);
			
			System.out.println("Your total: " + playerTotal);
			System.out.println();

			//output the dealer's cards
			System.out.println("Dealer's cards: ");

			printCardsSideBySide(dealerCards);

			System.out.println("Dealer's total: " + dealerTotal);
			System.out.println(); // add another line
			
			
			try {
				//ask the user if they want to hit or stand
				System.out.println("Do you want to hit or stand? (h/s)");
				opt = scan.next().toLowerCase();
				
				if (opt.equals("h") || opt.equals("hit")) {
					//create a temporary array to hold the player's cards plus 1 card
					String[] tempPlayerCards = new String[playerCards.length + 1];

					// Copy each card from the player's current hand to the new array.
					for (int i = 0; i < playerCards.length; i++) {
						tempPlayerCards[i] = playerCards[i];
					}

					// Add the new card to the end of the new array.
					int[] newCard = cardGen(dealtCards, playerAces);
					String newCardString = translate(newCard);
					tempPlayerCards[tempPlayerCards.length - 1] = newCardString;

					//generate a new card for the user
					newCard = cardGen(dealtCards, playerAces);
					newCardString = translate(newCard);
					tempPlayerCards[tempPlayerCards.length - 1] = newCardString;
					playerCards = tempPlayerCards;
					playerTotal = calculateTotal(playerCards, 0, playerAces);
					
					//check if the user won or bust
					if (playerTotal == 21) {
						//if player hits 21 and wins
						System.out.println("Your cards: ");
						printCardsSideBySide(playerCards);
						System.out.println();
						System.out.println("Your total: " + playerTotal);
						System.out.println();

						System.out.println("Dealer's cards: ");

						printCardsSideBySide(dealerCards);

						System.out.println("Dealer's total: " + dealerTotal);
						System.out.println(); // add another line
						System.out.println("You won!! You got " + userBet + " tokens!");
						tokens += userBet;
						continuePlaying = false;
					} else if (playerTotal > 21) {
						//when player busts
						System.out.println("Your cards: ");
						printCardsSideBySide(playerCards);
						System.out.println();
						System.out.println("Your total: " + playerTotal);
						System.out.println();

						System.out.println("Dealer's cards: ");

						printCardsSideBySide(dealerCards);

						System.out.println("Dealer's total: " + dealerTotal);
						System.out.println(); // add another line
						System.out.println("You busted! You lost " + userBet + " tokens");
						tokens -= userBet;
						continuePlaying = false;
					}
				} else if (opt.equals("s") || opt.equals("stand")) {
					//if they chose to stand
					System.out.println("You chose to stand with a total of " + playerTotal);
					
					//reveal the second dealer's card
					dealerCards[1] = translate(dCard2);
					
					
					do {
						// Generate a new card and update dealtCards and dealerAces
						int[] newDealCard = cardGen(dealtCards, dealerAces);

						// Create a new array with an additional slot for the new card
						String[] tempDealerCards = new String[dealerCards.length + 1];

						// Copy existing dealer cards to the new array
						for (int i = 0; i < dealerCards.length; i++) {
							tempDealerCards[i] = dealerCards[i];
						}

						// Translate the new card and add it to the new array
						tempDealerCards[tempDealerCards.length - 1] = translate(newDealCard);

						// Update dealerCards with the new array
						dealerCards = tempDealerCards;

						// Recalculate the dealer's total
						dealerTotal = calculateTotal(dealerCards, 0, dealerAces);

						System.out.println("Your cards: ");
						printCardsSideBySide(playerCards);

						System.out.println("Your total: " + playerTotal);

						System.out.println("Dealer's cards: ");
						printCardsSideBySide(dealerCards);

						System.out.println("Dealer's total: " + dealerTotal);
						continuePlaying = false;
					} while (dealerTotal < 17);
				} else {
					System.out.println("Invalid input. Please choose 'hit' or 'stand'.");
				}
			} catch (Exception e) {
				System.out.println("Please enter an integer value");
			}
		} while (continuePlaying == true);
		// Dealer's play
		if (playerTotal < 21) {
			System.out.println("Your cards: ");
			printCardsSideBySide(playerCards);
			System.out.println();
			System.out.println("Your total: " + playerTotal);
			System.out.println();

			System.out.println("Dealer's cards: ");

			printCardsSideBySide(dealerCards);

			System.out.println("Dealer's total: " + dealerTotal);
			System.out.println(); // add another line
			// Compare hands
			tokens = compareHands(playerTotal, dealerTotal, userBet, tokens);
		}
		return tokens; //return tokens
	}

	//create method compareHands that compares hands
	public static int compareHands(int playerTotal, int dealerTotal, int userBet, int tokens) {
		//check if the user busts
		if (dealerTotal > 21) {
			System.out.println("The dealer busted!! You win " + userBet + " tokens!");
			tokens += userBet;
			//check if the user is greater than dealer
		} else if (playerTotal > dealerTotal) {
			System.out.println("You won!! You win " + userBet + " tokens!");
			tokens += userBet;
		} else { //otherwise
			//if the player's total is equal to the dealer's total nothing happens
			if (playerTotal == dealerTotal) { 
				System.out.println("It's a push. Nothing happens to your tokens.");
				//otherwise
			} else {
				//the dealer wins and subtract from user's score
				System.out.println("Dealer wins. You lose " + userBet + " tokens.");
				tokens -= userBet;
			}
		}
		return tokens; //return tokens
	}
	
	//method to print lines
	public static void printLines(String[] lines) {
		//create a space between all cards
		for (int i = 0; i < lines.length; i++) {
			System.out.print(lines[i] + "   "); // Add space between cards
		}
		System.out.println(); //create a new line
	}

	//create a method to repeat a space
	public static String repeatSpace(int n) {
		//use stringBuilder to create a space
		StringBuilder spaces = new StringBuilder();
		for (int i = 0; i < n; i++) {
			spaces.append(" ");
		}
		return spaces.toString(); //return a space 
	}

}
